﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtLadoA.Focus();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
          
            try
            {
              
                double a = Convert.ToDouble(txtLadoA.Text);
                double b = Convert.ToDouble(txtLadoB.Text);
                double c = Convert.ToDouble(txtLadoC.Text);

                if (Math.Abs(b - c) < a && a < (b + c) &&
                    Math.Abs(a - c) < b && b < (a + c) &&
                    Math.Abs(a - b) < c && c < (a + b))
                {
                    if (a == b && b == c)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                    else if (a == b || a == c || b == c)
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo Escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Os lados informados NÃO formam um triângulo.");
                }
            }
            catch
            {
                MessageBox.Show("Erro: Digite apenas números válidos.");
            }
        }

    }

}
